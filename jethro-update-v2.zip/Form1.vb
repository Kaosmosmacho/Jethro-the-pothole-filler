﻿Public Class Form1

    Dim CLIP_PATH As String
    Dim FILEROOT As String
    Dim numzeros As Int16

    Private Sub BU_SELECT_CLIP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BU_SELECT_CLIP.Click
        Dim FLIST() As String
        Dim SSPLIT() As String
        Dim TSPLIT() As String
        Dim USPLIT() As String
        Dim CFILE As String
        Dim i As Int32

        FolderBrowserDialog1.SelectedPath = System.IO.Directory.GetCurrentDirectory

        FolderBrowserDialog1.Description = "Select Clip Folder"
        If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
            If FolderBrowserDialog1.SelectedPath <> "" Then
                CLIP_PATH = FolderBrowserDialog1.SelectedPath
                If System.IO.Directory.Exists(CLIP_PATH) = True Then
                    LB_PATH.Text = "PATH:" + CLIP_PATH

                    'create root clip name
                    FLIST = System.IO.Directory.GetFiles(CLIP_PATH)
                    For i = 0 To UBound(FLIST)
                        CFILE = FLIST(i)
                        If CFILE.Contains(".dng") = True Then
                            SSPLIT = Split(FLIST(i), CLIP_PATH)
                            If UBound(SSPLIT) > 0 Then
                                TSPLIT = Split(SSPLIT(1), ".dng")
                                CFILE = TSPLIT(0)
                                CFILE = Mid(CFILE, 2, Len(CFILE) - 1) 'remove \
                                USPLIT = Split(CFILE, "_")
                                USPLIT(UBound(USPLIT)) = ""

                                FILEROOT = Join(USPLIT, "_")
                                TB_FILEROOT.Text = FILEROOT

                                i = UBound(FLIST) + 1
                            End If
                        End If

                    Next i
                End If
            End If
        End If

    End Sub

    Private Sub BU_START_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BU_START.Click
        Dim FLIST() As String
        Dim SSPLIT() As String
        Dim TSPLIT() As String
        Dim USPLIT() As String
        Dim CFILE, SOURCEFRAME, NEWFRAME As String
        Dim CLIPNUMS(10000) As Int32
        Dim i, c_count, j, k, m As Int32

        FILEROOT = Trim(TB_FILEROOT.Text) 'allow modifications
        c_count = -1

        FLIST = System.IO.Directory.GetFiles(CLIP_PATH)
        For i = 0 To UBound(FLIST)
            CFILE = FLIST(i)
            If CFILE.Contains(".dng") = True Then
                'get clip numbers, file list should be in order
                SSPLIT = Split(FLIST(i), CLIP_PATH)
                If UBound(SSPLIT) > 0 Then
                    TSPLIT = Split(LCase(SSPLIT(1)), ".dng")
                    CFILE = TSPLIT(0)
                    CFILE = Mid(CFILE, 2, Len(CFILE) - 1) 'remove \
                    USPLIT = Split(CFILE, "_")
                    j = Val(USPLIT(UBound(USPLIT)))
                    numzeros = Len(USPLIT(UBound(USPLIT)))
                    c_count = c_count + 1

                    'resize memory
                    m = UBound(CLIPNUMS)
                    If m = c_count Then
                        ReDim Preserve CLIPNUMS(m + 2000)
                    End If

                    CLIPNUMS(c_count) = j
                End If
            End If
        Next i

        'time to process
        For i = 0 To (c_count - 1)
            If CLIPNUMS(i + 1) - CLIPNUMS(i) > 1 Then
                'here is a gap
                k = CLIPNUMS(i + 1) - CLIPNUMS(i) - 1
                SOURCEFRAME = CLIP_PATH + "\" + FILEROOT + ADDZS(Trim(Str(CLIPNUMS(i)))) + ".dng"
                For j = 1 To k
                    NEWFRAME = CLIP_PATH + "\" + FILEROOT + ADDZS(Trim(Str(CLIPNUMS(i) + j))) + ".dng"
                    'ready to copy
                    System.IO.File.Copy(SOURCEFRAME, NEWFRAME)
                Next j
            End If
        Next i

        MessageBox.Show("Complete", "Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Public Function ADDZS(ByVal instring As String) As String
        Dim i As Int16

        i = numzeros - Len(instring)

        While i > 0
            instring = "0" + instring
            i = i - 1
        End While

        Return instring

    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim r As MsgBoxResult

        r = MessageBox.Show("By downloading and using this software, the user assumes full responsibility and liability for the actions of the software. The software developer is not responsible for it's use or misuse. The software is given freely without any warranty. Do you agree to these terms?", "License Agreement", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If r = MsgBoxResult.No Then
            End
        End If
    End Sub
End Class
