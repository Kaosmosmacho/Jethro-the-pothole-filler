﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BU_SELECT_CLIP = New System.Windows.Forms.Button
        Me.BU_START = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.TB_FILEROOT = New System.Windows.Forms.TextBox
        Me.LB_PATH = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.Label3 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BU_SELECT_CLIP
        '
        Me.BU_SELECT_CLIP.Location = New System.Drawing.Point(16, 109)
        Me.BU_SELECT_CLIP.Name = "BU_SELECT_CLIP"
        Me.BU_SELECT_CLIP.Size = New System.Drawing.Size(161, 23)
        Me.BU_SELECT_CLIP.TabIndex = 0
        Me.BU_SELECT_CLIP.Text = "SELECT CLIP FOLDER"
        Me.BU_SELECT_CLIP.UseVisualStyleBackColor = True
        '
        'BU_START
        '
        Me.BU_START.Location = New System.Drawing.Point(277, 109)
        Me.BU_START.Name = "BU_START"
        Me.BU_START.Size = New System.Drawing.Size(75, 23)
        Me.BU_START.TabIndex = 1
        Me.BU_START.Text = "START"
        Me.BU_START.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(310, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Please backup clips before using this utility. Use at your own risk"
        '
        'TB_FILEROOT
        '
        Me.TB_FILEROOT.Location = New System.Drawing.Point(16, 83)
        Me.TB_FILEROOT.Name = "TB_FILEROOT"
        Me.TB_FILEROOT.Size = New System.Drawing.Size(350, 20)
        Me.TB_FILEROOT.TabIndex = 3
        '
        'LB_PATH
        '
        Me.LB_PATH.AutoSize = True
        Me.LB_PATH.Location = New System.Drawing.Point(13, 37)
        Me.LB_PATH.Name = "LB_PATH"
        Me.LB_PATH.Size = New System.Drawing.Size(39, 13)
        Me.LB_PATH.TabIndex = 4
        Me.LB_PATH.Text = "PATH:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(372, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "{FRAME NUM}.DNG"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Root Clip Name"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(489, 153)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LB_PATH)
        Me.Controls.Add(Me.TB_FILEROOT)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BU_START)
        Me.Controls.Add(Me.BU_SELECT_CLIP)
        Me.Name = "Form1"
        Me.Text = "Jethro the Pothole Filler"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BU_SELECT_CLIP As System.Windows.Forms.Button
    Friend WithEvents BU_START As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TB_FILEROOT As System.Windows.Forms.TextBox
    Friend WithEvents LB_PATH As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Label3 As System.Windows.Forms.Label

End Class
